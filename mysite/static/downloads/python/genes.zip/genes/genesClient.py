
def main():
    while 1:
        try:
            inp = int(input(('-' * 50) + '\nChoose a program to Run:\n\n1. Evaluate Sentence From Genes\n2. Genes Sentence Builder\n3. Genes Word Check\n4. Exit\n\n>> '))
            print('-' * 50)
            if inp == 1:
                import evaluateSentenceFromGenes
            elif inp == 2:
                import genesSentenceBuilder
            elif inp == 3:
                import genesWordCheck
            elif inp == 4:
                break
            else:
                print("NOT A VALID NUMBER")
        except:
            print(('-' * 50) + "\nNOT A NUMBER VALUE")

main()

