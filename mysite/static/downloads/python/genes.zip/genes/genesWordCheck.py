import requests
import random as r

wordsURL = 'https://raw.githubusercontent.com/dwyl/english-words/master/words.txt'
words = requests.get(wordsURL).text.upper().split('\n')

fullName = {
    'A' : 'Alaline',
    'C' : 'Cysteine',
    'D' : 'Aspartic acid',
    'E' : 'Glutamic acid',
    'F' : 'Phenylalanine',
    'G' : 'Glycine',
    'H' : 'Histodine',
    'I' : 'Isoleucine',
    'K' : 'Lysine',
    'L' : 'Leucine',
    'M' : 'Methionine',
    'N' : 'Asparagine',
    'P' : 'Proline',
    'Q' : 'Glutamine',
    'R' : 'Arginine',
    'S' : 'Serine',
    'T' : 'Threonine',
    'V' : 'Valine',
    'W' : 'Tryptophan',
    'Y' : 'Tyrosine',
    ' ' : 'Stop'
}

C2DNA = {
    'A' : ['GCA','GCT','GCC','GCG'],
    'C' : ['TGT','TGC'],
    'D' : ['GAT','GAC'],
    'E' : ['GAA','GAG'],
    'F' : ['TTT','TTC'],
    'G' : ['GGA','GGT','GGC','GGG'],
    'H' : ['CAT','CAC'],
    'I' : ['ATA','ATC','ATT'],
    'K' : ['AAG','AAA'],
    'L' : ['TTA','TTG','CTA','CTT','CTC','CTG'],
    'M' : ['ATG'],
    'N' : ['AAC','AAT'],
    'P' : ['CCA','CCT','CCC','CCG'],
    'Q' : ['CAG','CAA'],
    'R' : ['CGA','CGT','CGC','CGG','AGA','AGG'],
    'S' : ['TCA','TCT','TCC','TCG','AGC','AGT'],
    'T' : ['ACA','ACT','ACC','ACG'],
    'V' : ['GTA','GTT','GTC','GTG'],
    'W' : ['TGG'],
    'Y' : ['TAT','TAC'],
    ' ' : ['TAA','TAG','TGA']
}

# ------ starter --------------------------------
available = 'acdefghiklmnpqrstvwy '.upper()
avWords = []
badWords = []
for word in words:
    GOOD = True
    for letter in word:
        if not letter in available:
            GOOD = False
            break
    if GOOD:
        avWords.append(word)
    else:
        badWords.append(word)
# --------------------------------------------------
# ----- functions ----------------------------------
def possibleWords(word):
    word = word.upper()
    pWords = []
    for i in range(len(avWords)):
        if word in avWords[i]:
            if avWords[i].index(word) == 0:
                pWords.append(i)
    return pWords

def checkWord(word):
    word = word.upper()
    GOOD = True
    for letter in word:
        if not letter in available:
            GOOD = False
    return GOOD
# ----------------------------------------------------

def main():
    while 1:
        word = input('Give a word to check or "Q" to exit:\n>> ')
        if word == 'Q':
            break
        GOOD = checkWord(word)
        if GOOD:
            print('{} is a proper value.'.format(word))
            pWords = possibleWords(word)
            for i in range(0,len(pWords)):
                aac = ''
                for letter in avWords[pWords[i]]:
                    aac += r.choice(C2DNA[letter])
                print('{}. {} - {}'.format(i,avWords[pWords[i]],aac))
        else:
            print('{} is not a proper value.'.format(word))
        print('-' * 50)
        
main()
