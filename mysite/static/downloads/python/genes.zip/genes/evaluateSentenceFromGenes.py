import random as r

fullName = {
    'A' : 'Alaline',
    'B' : 'Hold',
    'C' : 'Cysteine',
    'D' : 'Aspartic acid',
    'E' : 'Glutamic acid',
    'F' : 'Phenylalanine',
    'G' : 'Glycine',
    'H' : 'Histodine',
    'I' : 'Isoleucine',
    'J' : 'Hold',
    'K' : 'Lysine',
    'L' : 'Leucine',
    'M' : 'Methionine',
    'N' : 'Asparagine',
    'O' : 'Hold',
    'P' : 'Proline',
    'Q' : 'Glutamine',
    'R' : 'Arginine',
    'S' : 'Serine',
    'T' : 'Threonine',
    'U' : 'Hold',
    'V' : 'Valine',
    'W' : 'Tryptophan',
    'X' : 'Hold',
    'Y' : 'Tyrosine',
    'Z' : 'Hold',
    ' ' : 'Stop'
}

C2TRN = {
    'A' : ['GCA','GCT','GCC','GCG'],
    'B' : ['ABA'],
    'C' : ['TGT','TGC'],
    'D' : ['GAT','GAC'],
    'E' : ['GAA','GAG'],
    'F' : ['TTT','TTC'],
    'G' : ['GGA','GGT','GGC','GGG'],
    'H' : ['CAT','CAC'],
    'I' : ['ATA','ATC','ATT'],
    'J' : ['TJT'],
    'K' : ['AAG','AAA'],
    'L' : ['TTA','TTG','CTA','CTT','CTC','CTG'],
    'M' : ['ATG'],
    'N' : ['AAC','AAT'],
    'O' : ['COC'],
    'P' : ['CCA','CCT','CCC','CCG'],
    'Q' : ['CAG','CAA'],
    'R' : ['CGA','CGT','CGC','CGG','AGA','AGG'],
    'S' : ['TCA','TCT','TCC','TCG','AGC','AGT'],
    'T' : ['ACA','ACT','ACC','ACG'],
    'U' : ['GUG'],
    'V' : ['GTA','GTT','GTC','GTG'],
    'W' : ['TGG'],
    'X' : ['AXA'],
    'Y' : ['TAT','TAC'],
    'Z' : ['TZT'],
    ' ' : ['TAA','TAG','TGA']
}

def main():
    while 1:
        seq = input('Give a sequence of DNA to translate to nucleotides or "Q" to exit:\n>> ').upper()
        res = ''
        if seq == 'Q':
            break
        for i in range(0,len(seq),3):
            try:
                val = '{}{}{}'.format(seq[i],seq[i+1],seq[i+2])
                lkey = ''
                for key in C2TRN.keys():
                    if val in C2TRN[key]:
                        res += key
                        lkey = key
                        break
                print('{} -> {} ~ {}'.format(val,lkey,fullName[lkey]))
            except:
                continue
        print(res)

main()













