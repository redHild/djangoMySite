import random as r

fullName = {
    'A' : 'Alaline',
    'C' : 'Cysteine',
    'D' : 'Aspartic acid',
    'E' : 'Glutamic acid',
    'F' : 'Phenylalanine',
    'G' : 'Glycine',
    'H' : 'Histodine',
    'I' : 'Isoleucine',
    'K' : 'Lysine',
    'L' : 'Leucine',
    'M' : 'Methionine',
    'N' : 'Asparagine',
    'P' : 'Proline',
    'Q' : 'Glutamine',
    'R' : 'Arginine',
    'S' : 'Serine',
    'T' : 'Threonine',
    'V' : 'Valine',
    'W' : 'Tryptophan',
    'Y' : 'Tyrosine',
    ' ' : 'Stop'
}

C2DNA = {
    'A' : ['GCA','GCT','GCC','GCG'],
    'C' : ['TGT','TGC'],
    'D' : ['GAT','GAC'],
    'E' : ['GAA','GAG'],
    'F' : ['TTT','TTC'],
    'G' : ['GGA','GGT','GGC','GGG'],
    'H' : ['CAT','CAC'],
    'I' : ['ATA','ATC','ATT'],
    'K' : ['AAG','AAA'],
    'L' : ['TTA','TTG','CTA','CTT','CTC','CTG'],
    'M' : ['ATG'],
    'N' : ['AAC','AAT'],
    'P' : ['CCA','CCT','CCC','CCG'],
    'Q' : ['CAG','CAA'],
    'R' : ['CGA','CGT','CGC','CGG','AGA','AGG'],
    'S' : ['TCA','TCT','TCC','TCG','AGC','AGT'],
    'T' : ['ACA','ACT','ACC','ACG'],
    'V' : ['GTA','GTT','GTC','GTG'],
    'W' : ['TGG'],
    'Y' : ['TAT','TAC'],
    ' ' : ['TAA','TAG','TGA']
}

C2TRN = {
    'A' : ['GCA','GCT','GCC','GCG'],
    'B' : ['ABA'],
    'C' : ['TGT','TGC'],
    'D' : ['GAT','GAC'],
    'E' : ['GAA','GAG'],
    'F' : ['TTT','TTC'],
    'G' : ['GGA','GGT','GGC','GGG'],
    'H' : ['CAT','CAC'],
    'I' : ['ATA','ATC','ATT'],
    'J' : ['TJT'],
    'K' : ['AAG','AAA'],
    'L' : ['TTA','TTG','CTA','CTT','CTC','CTG'],
    'M' : ['ATG'],
    'N' : ['AAC','AAT'],
    'O' : ['COC'],
    'P' : ['CCA','CCT','CCC','CCG'],
    'Q' : ['CAG','CAA'],
    'R' : ['CGA','CGT','CGC','CGG','AGA','AGG'],
    'S' : ['TCA','TCT','TCC','TCG','AGC','AGT'],
    'T' : ['ACA','ACT','ACC','ACG'],
    'U' : ['GUG'],
    'V' : ['GTA','GTT','GTC','GTG'],
    'W' : ['TGG'],
    'X' : ['AXA'],
    'Y' : ['TAT','TAC'],
    'Z' : ['TZT'],
    ' ' : ['TAA','TAG','TGA']
}

available = 'acdefghiklmnpqrstvwy '.upper()

# ----- functions ----------------------------------
def checkSeq(seq):
    seq = seq.upper()
    GOOD = True
    for letter in seq:
        if not letter in available:
            GOOD = False
            break
    return GOOD
# ----------------------------------------------------

def main():
    while 1:
        seq = input('Give a statement to translate or "Q" to exit:\n>> ')
        if seq == 'Q':
            break
        if checkSeq(seq):
            trn = ''
            for val in seq:
                trn += r.choice(C2DNA[val.upper()])
            print('\nREAL TRANSLATION\n\n>>{}<<\n\n translates to... \n\n>>{}<<\n\n'.format(seq,trn))
        else:
            trn = ''
            for val in seq:
                trn += r.choice(C2TRN[val.upper()])
            print('\nFALSE TRANSLATION\n\n>>{}<<\n\n translates to... \n\n>>{}<<\n'.format(seq,trn))
        print('-' * 50)
        print()
        
        
main()
