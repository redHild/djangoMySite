# RandomMusicGenerator
A Python script that is used for generating music randomly with a few preset options which are also chosen at random.

To use, open the python file, pygame will run and show a screen with instructions.

1. to save a song, go into songs folder and rename "output.mid" file while you hear the song you want to save.
2. to start a new song, just click the view port.
3. to exit the program, click the red X at the top and click the view port again.

# BUGS
1. Sometimes when I start the program or click to start a new song, the program crashes.
