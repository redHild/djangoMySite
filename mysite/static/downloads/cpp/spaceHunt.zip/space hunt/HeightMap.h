#pragma once

#include <vector>
#include <iostream>

#include "Block.h"

using namespace std;

class HeightMap {
private:
	float f(float t) {
		t = fabsf(t);
		return t >= 1.0f ? 0.0f : 1.0f - (3.0f - 2.0f * t) * t * t;
	}
	float surflet(float x, float y, float grad_x, float grad_y) {
		return f(x) * f(y) * (grad_x * x + grad_y * y);
	}
public:
	static int const size = 16 * 128;
	static int const mask = size - 1;
	static int const height = 32;
	int perm[size];
	float grads_x[size], grads_y[size];

	int getVal(int _x, int _y) {
		float x = grads_x[_x];
		float y = grads_y[_y];
		float result = 0.0f;
		int cell_x = floorf(x);
		int cell_y = floorf(y);
		for (int grid_y = cell_y; grid_y <= cell_y + 1; ++grid_y)
			for (int grid_x = cell_x; grid_x <= cell_x + 1; ++grid_x) {
				int hash = perm[(perm[grid_x & mask] + grid_y) & mask];
				result += surflet(x - grid_x, y - grid_y, grads_x[hash], grads_y[hash]);
			}
		return (1 + (result + 1) * (height - 1) / 2);
	}
	int getLowest() {
		int lowest = height + 1;
		for (int x = 0; x < size; x++)
			for (int z = 0; z < size; z++)
				lowest = (getVal(x, z) < lowest) ? getVal(x, z) : lowest;
		return lowest;
	}
	HeightMap() {
		for (int index = 0; index < size; ++index) {
			int other = rand() % (index + 1);
			if (index > other)
				perm[index] = perm[other];
			perm[other] = index;
			grads_x[index] = cosf(2.0f * 3.1415926 * index / size);
			grads_y[index] = sinf(2.0f * 3.1415926 * index / size);
		}
	}
};