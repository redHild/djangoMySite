#pragma once

#include <iostream>
#include <vector>

using namespace std;

/*
 * block types:
 *
 * 0 - bedrock      // color black // meant to be unbreakable
 * 1 - grass        // color green
 * 2 - dirt         // color brown
 * 3 - stone        // color grey
 * 4 - cloud        // color white
 * 5 - easter egg   // color red
 *
 */
class Block {
private:
	int x, y, z, type, top, btm, nrt, sth, est, wst;
	float r, g, b;
public:
	int getX();
	int getY();
	int getZ();
	bool isEgg();
	void show();
	Block(int _type, int _x, int _y, int _z);
};