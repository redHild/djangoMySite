#include "Block.h"
#include "Chunk.h"

#include <iostream>
#include <vector>

#include <GL/glew.h>
#include <GL/freeglut.h>

using namespace std;

int Block::getX() { return x; }
int Block::getY() { return y; }
int Block::getZ() { return z; }

bool Block::isEgg() { return type == 5; }

void Block::show() {
	glPushMatrix();

	// material Color
	GLfloat rgb[] = { r, g, b, 1.0 };
	glMaterialfv(GL_FRONT, GL_AMBIENT, rgb);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, rgb);

	glColor3f(r, g, b);
	// top. if block directly next to this block to the top, don't show top face
	if (top == 1) {
		glNormal3f(0, 1, 0);
		glBegin(GL_POLYGON);
		glVertex3f(x + .5, y + .5, z + .5);
		glVertex3f(x - .5, y + .5, z + .5);
		glVertex3f(x - .5, y + .5, z - .5);
		glVertex3f(x + .5, y + .5, z - .5);
		glEnd();
	}
	// bottom. if block directly next to this block to the bottom, don't show bottom face
	if (btm == 1) {
		glNormal3f(0, -1, 0);
		glBegin(GL_POLYGON);
		glVertex3f(x + .5, y - .5, z + .5);
		glVertex3f(x - .5, y - .5, z + .5);
		glVertex3f(x - .5, y - .5, z - .5);
		glVertex3f(x + .5, y - .5, z - .5);
		glEnd();
	}
	// north. if block directly next to this block to the north, don't show north face
	if (nrt == 1) {
		glNormal3f(0, 0, -1);
		glBegin(GL_POLYGON);
		glVertex3f(x + .5, y + .5, z + .5);
		glVertex3f(x - .5, y + .5, z + .5);
		glVertex3f(x - .5, y - .5, z + .5);
		glVertex3f(x + .5, y - .5, z + .5);
		glEnd();
	}
	// south. if block directly next to this block to the south, don't show south face
	if (sth == 1) {
		glNormal3f(0, 0, 1);
		glBegin(GL_POLYGON);
		glVertex3f(x + .5, y + .5, z - .5);
		glVertex3f(x - .5, y + .5, z - .5);
		glVertex3f(x - .5, y - .5, z - .5);
		glVertex3f(x + .5, y - .5, z - .5);
		glEnd();
	}
	// east. if block directly next to this block to the east, don't show east face
	if (est == 1) {
		glNormal3f(-1, 0, 0);
		glBegin(GL_POLYGON);
		glVertex3f(x + .5, y + .5, z + .5);
		glVertex3f(x + .5, y - .5, z + .5);
		glVertex3f(x + .5, y - .5, z - .5);
		glVertex3f(x + .5, y + .5, z - .5);
		glEnd();
	}
	// west. if block directly next to this block to the west, don't show west face
	if (wst == 1) {
		glNormal3f(1, 0, 0);
		glBegin(GL_POLYGON);
		glVertex3f(x - .5, y + .5, z + .5);
		glVertex3f(x - .5, y - .5, z + .5);
		glVertex3f(x - .5, y - .5, z - .5);
		glVertex3f(x - .5, y + .5, z - .5);
		glEnd();
	}

	glPopMatrix();
}

Block::Block(int _type, int _x, int _y, int _z) {
	type = _type;
	x = _x;
	y = _y;
	z = _z;

	if (type == 1) top = 1, btm = 0, nrt = 1, sth = 1, est = 1, wst = 1;
	//else if(type == 2 || type == 3) top = 0, btm = 0, nrt = 1, sth = 1, est = 1, wst = 1;
	else if (type == 5) top = 1, btm = 1, nrt = 1, sth = 1, est = 1, wst = 1;
	else top = 0, btm = 0, nrt = 0, sth = 0, est = 0, wst = 0;

	if (type == 0) r = 0, g = 0, b = 0;
	else if (type == 1) {
		float off = ((rand() % 127) / 255.0);
		r = off, g = 1.0, b = off;
	}
	else if (type == 2) r = .75, g = .40, b = .05;
	else if (type == 3) r = .6, g = .6, b = .6;
	else if (type == 4) r = 1, g = 1, b = 1;
	else if (type == 5) r = 1, g = 0, b = 0;
};