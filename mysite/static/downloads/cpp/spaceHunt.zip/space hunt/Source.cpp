#include <cstdlib>
#include <cmath>
#include <iostream>
#include <String>
#include <vector>

#include <time.h>

#include <GL/glew.h>
#include <GL/freeglut.h>

#include "Player.h"
#include "Block.h"
#include "Chunk.h"
#include "HeightMap.h"

#define PI 3.1415926
#define TAU PI*2

using namespace std;

static Player player;
static vector<vector<Chunk>> world;
static HeightMap map;

static vector<vector<GLfloat>> stars;
static vector<vector<int>> easterEggs;
static vector<vector<int>> easterEggsFound;

static int chunkWidth = 8;
static int worldSize = 32;
static int renderDistance = 6;
static float sunRot = 0.0, sunSpd = 0.1 / (60 / 3);
static int score = 0;

static int width;
static int height;

// ------------------------------------------------------------------------------------------
void spcKeys(int key, int x, int y) {
	if (key == 27)
		exit(0);
}
/*
 * Testing for multiple characters at once, still not perfectly smooth though.
 * Whenever I ask for input for the character, I will give their input a vector
 * of characters.
 */
vector<char> keysPressed;
void keyUp(unsigned char key, int x, int y) {
	for (int index = 0; index < keysPressed.size(); index++)
		if (keysPressed[index] == key) keysPressed.erase(keysPressed.begin() + index);
}
void keyDown(unsigned char key, int x, int y) {
	bool add = true;
	for (int index = 0; index < keysPressed.size(); index++)
		if (keysPressed[index] == key) {
			add = false;
			break;
		}
	if (add) keysPressed.push_back(key);

	// keyboard input to player movement
	for (char k : keysPressed) {
		if      (k == 'w' || k == 'W') player.movement(1);
		else if (k == 'a' || k == 'A') player.movement(2);
		else if (k == 's' || k == 'S') player.movement(3);
		else if (k == 'd' || k == 'D') player.movement(4);
		else if (k == 'r' || k == 'R') player.movement(5);
		else if (k == 'f' || k == 'F') player.movement(6);
		else if (k == '=') renderDistance++;
		else if (k == '-') renderDistance--;
	}
}
void passiveMouse(int x, int y) {
	float rotspd = .0001;
	player.setXRot(-((width / 2) - x) * rotspd);
	player.setYRot(((height / 2) - y) * rotspd);
	glutWarpPointer(width / 2, height / 2);
}
void mouse(int btn, int state, int x, int y) {
	if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
		for (int e = 0; e < easterEggs.size() ; e++)
			if (easterEggs[e][0] == (int)player.xLookAt() &&
				easterEggs[e][1] == (int)player.yLookAt() &&
				easterEggs[e][2] == (int)player.zLookAt()) {
				score++;
				cout << "Egg found!! Score: " << score << endl;
				if (score == 8)
					cout << "Congrats!! You found all the eggs!\nNow you can fly back to your home planet\nto hatch your babies!\n";
				easterEggsFound.push_back(easterEggs[e]);
				easterEggs.erase(easterEggs.begin() + e);
				break;
			}
	}
}
// ------------------------------------------------------------------------------------------

void drawScene(void) {
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);

	GLfloat pos[] = { player.getX(), player.getY() , player.getZ(), 1.0 };
	GLfloat sun[] = { 0.0, 0.0, sunRot , 0.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, pos);
	sunRot = (sunRot > 0.99) ? -0.99 : sunRot + sunSpd;
	
	glPushMatrix();

	int pChunkX = (player.getX() / chunkWidth) + 1;
	int pChunkY = (player.getZ() / chunkWidth) + 1;

	for(int i = pChunkX - renderDistance + 1; i <= pChunkX + renderDistance + 2; i++)
		for (int j = pChunkY - renderDistance + 1; j <= pChunkY + renderDistance + 2; j++)
			if ((i >= 0 && j >= 0) && (i <= worldSize && j <= worldSize)) world[i][j].draw();

	glPushMatrix();
	glPushMatrix();
	// material Color
	GLfloat rgb[] = { .9, .1, .9, 1.0 };
	glMaterialfv(GL_FRONT, GL_AMBIENT, rgb);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, rgb);
	glTranslatef(player.xLookAt(),player.yLookAt(),player.zLookAt());
	glRotatef(player.getYRot(), 0, 1, 0);
	glScalef(1, .5, 1);
	glutSolidSphere(.25,4,10);
	glPopMatrix();
	glPushMatrix();
	// material Color
	float sr = 0, sg = 0, sb = 0;
	for (vector<int> egg : easterEggs)
		if (egg[0] == (int)player.xLookAt() &&
			egg[1] == (int)player.yLookAt() &&
			egg[2] == (int)player.zLookAt()) {
			sr = 1, sg = 1, sb = 1;
			break;
		}
	GLfloat rgbs[] = { sr, sg, sb, 0.5 };
	glMaterialfv(GL_FRONT, GL_AMBIENT, rgbs);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, rgbs);
	glTranslatef(player.xLookAt(), player.yLookAt(), player.zLookAt());
	glRotatef(player.getYRot(), 0, 1, 0);
	glScalef(1, .5, 1);
	glutWireSphere(.27, 4, 10);
	glPopMatrix();
	glPopMatrix();

	for (vector<int> egg : easterEggsFound) {
		glPushMatrix();
		GLfloat rgbe[] = { 0, 1, 1, 1.0 };
		glMaterialfv(GL_FRONT, GL_AMBIENT, rgbe);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, rgbe);
		glTranslatef(egg[0],egg[1],egg[2]);
		glScalef(1.2, 200, 1.2);
		glutWireSphere(1, 4, 10);
		glPopMatrix();
	}

	for (vector<GLfloat> star : stars) {
		glBegin(GL_POINTS);
		glColor3f(1,1,1);
		glVertex3f(star[0],star[1],star[2]);
		glEnd();
	}

	glPopMatrix();

	glFlush();
}

void genWorld() {

	srand(time(NULL));

	map = HeightMap();

	int lowestHeight = map.getLowest();

	world = vector<vector<Chunk>>();

	vector<Chunk> tempRow = vector<Chunk>();
	for (int i = -worldSize; i <= worldSize; i++) {
		for (int j = -worldSize; j <= worldSize; j++)
			tempRow.push_back(Chunk(i, j));
		world.push_back(tempRow);
		tempRow.clear();
	}
	int scale = 12;

	cout << "-CURRENTLY LOADING-" << endl;

	vector<vector<int>> eggs = vector<vector<int>>();
	easterEggs = vector<vector<int>>();
	easterEggsFound = vector<vector<int>>();
	// easter eggs setup
	for (int i = 0; i < 8; i++)
		eggs.push_back({ (rand() % (worldSize) + 4) - 2, (rand() % (worldSize) + 4) - 2 });

	for (int i = 0; i <= worldSize * 2; i++)
		for (int j = 0; j < worldSize * 2; j++)
			for (int x = 0; x < chunkWidth; x++)
				for (int z = 0; z < chunkWidth; z++) {
					world[i][j].addBlock(Block(0, ((i * chunkWidth) - worldSize) + x, -1, ((j * chunkWidth) - worldSize) + z));
					int height = map.getVal((((i * chunkWidth) - worldSize) + x) * scale, (((j * chunkWidth) - worldSize) + z) * scale) - lowestHeight;
					world[i][j].addBlock(Block(1, ((i * chunkWidth) - worldSize) + x, height, ((j * chunkWidth) - worldSize) + z));
					// adding eggs
					for (int e = 0; e < eggs.size(); e++)
						if (eggs[e][0] == i && eggs[e][1] == j) {
							int rx = rand() % chunkWidth;
							int rz = rand() % chunkWidth;
							world[i][j].addBlock(Block(5, ((i * chunkWidth) - worldSize) + rx, height + 1, ((j * chunkWidth) - worldSize) + rz));
							eggs.erase(eggs.begin() + e);
							easterEggs.push_back({ ((i * chunkWidth) - worldSize) + rx, height + 1, ((j * chunkWidth) - worldSize) + rz });
						}
				}

	// stars setup
	glPointSize( 1.5 );
	stars = vector<vector<GLfloat>>();
	for (int i = 0; i < 1000; i++)
		stars.push_back({
			(float)((rand() % (worldSize * chunkWidth * 100) / 100.0) + 128) - 64,
			((float)(rand() % (200 * 100) / 100.0)) + 40,
			(float)((rand() % (worldSize * chunkWidth * 100) / 100.0) + 128) - 64
		});
	cout << "-WORLD GENERATED-\n\n" << endl;
}

// Initialization routine.
void setup(void) {
	glClearColor(0.007, 0.02, 0.51, 0.0);
	glutSetCursor(GLUT_CURSOR_NONE);

	//srand(time(NULL));

	// lighting time
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	GLfloat ambient[] = { 0.01, 0.01, 0.01, 1.0 };
	GLfloat diffuse[] = { 0.51, 0.51, 0.98, 1.0 };
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

	width  = 800;
	height = 800;

	keysPressed = vector<char>();

	player = Player(worldSize,chunkWidth, map);

	genWorld();

	cout << "      SPACE HUNT      " << endl;
	cout << "   By Jakob C. Hild   " << endl;
	cout << "______________________" << endl;
	cout << "" << endl;
	cout << "controls:" << endl;
	cout << "W to go forward" << endl;
	cout << "S to go backward" << endl;
	cout << "A to go left" << endl;
	cout << "D to go right" << endl;
	cout << "R to go up" << endl;
	cout << "F to go down" << endl;
	cout << "" << endl;
	cout << "Mouse controls where you look." << endl;
	cout << "Pressing - or + will increase or decrease\nor incrase render distance." << endl;
	cout << "" << endl;
	cout << "Press 'esc' key to close game" << endl;
}

// OpenGL window reshape routine.
void resize(int w, int h) {
	width = w, height = h;
	glViewport(0, 0, w, h);
}

void camControl() {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90, (double)width / (double)height, 0.01, 1000);

	gluLookAt(player.getX(), player.getY(), player.getZ(),
			  player.xLookAt(), player.yLookAt(), player.zLookAt(),
			   0,  1,  0);

	glMatrixMode(GL_MODELVIEW);
}

void refresh(int ms) {
	camControl();
	glutPostRedisplay();
	glutTimerFunc(ms, refresh, ms);
}

// Main routine.
int main(int argc, char **argv) {
	glutInit(&argc, argv);

	glutInitContextVersion(4, 3);
	glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("FINAL PROJECT");
	glutDisplayFunc(drawScene);
	glutReshapeFunc(resize);
	
	// input
	glutKeyboardFunc(keyDown);
	glutKeyboardUpFunc(keyUp);
	glutSpecialFunc(spcKeys);
	glutMouseFunc(mouse);
	glutPassiveMotionFunc(passiveMouse);

	glutTimerFunc(33, refresh, 33);

	setup();

	glutMainLoop();
}

/*
 * NOTES FOR THIS PROJECT
 *
 * KEYBOARD INPUT:
 * w moves player forward
 * a moves player left
 * s moves player backwards
 * d moves player right
 *
 */