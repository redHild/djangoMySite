#pragma once

#include <cmath>
#include <iostream>
#include <vector>

#include "HeightMap.h"

using namespace std;

#define PI 3.1415926
#define TAU PI*2

class Player {
private:
	float x = 0, y = 0, z = 0, xrot = .5, yrot = .5, spd = .8;
	int worldSize, chunkWidth;
	HeightMap map;
public:
	Player();
	Player(int _worldSize, int _chunkWidth, HeightMap _map) {
		map = _map;
		worldSize = _worldSize;
		chunkWidth = _chunkWidth;

		x = (worldSize * chunkWidth) / 2;
		z = (worldSize * chunkWidth) / 2;
		y = map.getVal(x,z) + 2;
	}
	float getX() { return x; }
	float getY() { return y; }
	float getZ() { return z; }
	float getXRot() { return xrot; }
	float getYRot() { return yrot; }
	void setXRot(float r) {
		if (xrot + r < 0) xrot++;
		else if(xrot + r > 1) xrot--;
		xrot += r;
	}
	void setYRot(float r) {
		if (yrot + r > 0 && yrot + r < .98) 
			yrot += r;
	}
	float xLookAt() { return x + (sin(yrot*PI) * cos(xrot*(PI * 2))); }
	float yLookAt() { return y + (- cos(yrot*PI)); }
	float zLookAt() { return z + (sin(yrot*PI) * sin(xrot*(PI * 2))); }
	void movement(int inp) {
		float dx = 0;
		float dy = 0;
		float dz = 0;

		if (inp == 1) { // forward
			dx = spd * cos(xrot * TAU);
			dz = spd * sin(xrot * TAU);
		} else if (inp == 2) { // left
			dx = spd * cos((xrot + .75) * TAU);
			dz = spd * sin((xrot + .75) * TAU);
		} else if (inp == 3) { // backward
			dx = spd * cos((xrot + .50) * TAU);
			dz = spd * sin((xrot + .50) * TAU);
		} else if (inp == 4) { // right
			dx = spd * cos((xrot + .25) * TAU);
			dz = spd * sin((xrot + .25) * TAU);
		} else if (inp == 5) { // TEST CONTROLS go up
			dy = spd;
		} else if (inp == 6) { // TEST CONTROLS go down
			dy = -spd;
		}

		// boundry checking
		//border
		if (x + dx <= -chunkWidth * 4) dx *= -1;
		else if (x + dx >= ((worldSize - 4) * chunkWidth)) dx *= -1;
		if (z + dz <= -chunkWidth * 4) dz *= -1;
		else if (z + dz >= ((worldSize - 4) * chunkWidth)) dz *= -1;
		// height checking
		if (y + dy >= 100) dy *= -1;


		x += dx;
		y += dy;
		z += dz;
	}
};

