#pragma once

#include <vector>
#include <iostream>

#include "Block.h"

using namespace std;

class Chunk {
private:
	int x, z, i, j, w = 8, size;
	vector<Block> chunk;
public:
	Chunk();
	Chunk(int _i, int _j);
	vector<Block> getChunk();
	int getX();
	int getZ();
	int getWidth();
	void addBlock(Block newBlock);
	void rmvEgg();
	void draw();
};