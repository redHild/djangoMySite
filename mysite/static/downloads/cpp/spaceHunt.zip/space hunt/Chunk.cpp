#include "Chunk.h"

Chunk::Chunk()
{
}

Chunk::Chunk(int _i, int _j) {
	i = _i;
	j = _j;
	x = i * w;
	z = j * w;
}

vector<Block> Chunk::getChunk() {
	return chunk;
}

int Chunk::getX() { return x; }
int Chunk::getZ() { return z; }
int Chunk::getWidth() { return w; }
void Chunk::addBlock(Block newBlock) { chunk.push_back(newBlock); }

void Chunk::rmvEgg() {
	for (int i = 0; i < chunk.size(); i++)
		if (chunk[i].isEgg()) chunk.erase(chunk.begin() + i);
}

void Chunk::draw() {
	for (Block block : chunk)
		block.show();
}